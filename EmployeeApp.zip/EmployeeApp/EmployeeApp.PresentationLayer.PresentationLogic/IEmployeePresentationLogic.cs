﻿using EmployeeApp.PresentationLayer.UI.Web.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using EmployeeModel = EmployeeApp.PresentationLayer.UI.Web.Model.Employee;

namespace EmployeeApp.PresentationLayer.PresentationLogic
{
	public interface IEmployeePresentationLogic
	{
		bool SaveEmployeeDetail(EmployeeModel employee);
        EmployeeModel GetEmployeeDetail(int employeeId);
		bool DeleteEmployee(int employeeId);
	}
}
