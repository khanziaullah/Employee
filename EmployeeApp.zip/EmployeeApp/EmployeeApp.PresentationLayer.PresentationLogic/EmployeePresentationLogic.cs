﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeApp.PresentationLayer.PresentationLogic.EmployeeServiceReference;
using EmployeeModel = EmployeeApp.PresentationLayer.UI.Web.Model.Employee;

namespace EmployeeApp.PresentationLayer.PresentationLogic
{
    public class EmployeePresentationLogic : IEmployeePresentationLogic
    {
        IEmployeeService client;

        public EmployeePresentationLogic(IEmployeeService client)
        {
            this.client = client;
        }

        public bool DeleteEmployee(int employeeId)
        {
            throw new NotImplementedException();
        }

        public EmployeeModel GetEmployeeDetail(int employeeId)
        {
            var request = new GetEmployeeDetailsRequest
            {
                RequestId = Guid.NewGuid(),
                EmployeeId = employeeId
            };

            var response = client.GetEmployeeDetails(request);

            return new EmployeeModel
            {
                FirstName = response.FirstName,
                LastName = response.LastName,
                Address = response.Address,
            };
        }

        public bool SaveEmployeeDetail(EmployeeModel employee)
        {
            throw new NotImplementedException();
        }
    }
}
