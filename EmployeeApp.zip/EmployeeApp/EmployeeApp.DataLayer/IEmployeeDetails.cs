﻿using EmployeeApp.DataLayer.Model;

namespace EmployeeApp.DataLayer
{
    public interface IEmployeeDetails
    {
        EmployeeDTO GetEmployeeDetail(int employeeId);
        bool SaveEmployeeDetail(EmployeeDTO employee);
    }
}