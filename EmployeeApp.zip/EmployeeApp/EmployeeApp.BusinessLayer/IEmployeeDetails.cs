﻿using EmployeeApp.DataLayer.Model;

namespace EmployeeApp.BusinessLayer
{
    public interface IEmployeeDetails
    {
        EmployeeDTO GetEmployeeDetail(int employeeId);
        bool SaveEmployeeDetail(EmployeeDTO employee);
    }
}