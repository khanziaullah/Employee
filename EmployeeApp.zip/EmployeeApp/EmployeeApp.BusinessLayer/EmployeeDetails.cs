﻿using EmployeeApp.DataLayer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeApp.DataLayer;

namespace EmployeeApp.BusinessLayer
{
    public class EmployeeDetails : IEmployeeDetails
    {
        DataLayer.IEmployeeDetails employeeDetails;

        public EmployeeDetails(DataLayer.IEmployeeDetails employeeDetails)
        {
            this.employeeDetails = employeeDetails;
        }

        public bool SaveEmployeeDetail(EmployeeDTO employee)
        {
            return employeeDetails.SaveEmployeeDetail(employee);
        }

        public EmployeeDTO GetEmployeeDetail(int employeeId)
        {
            return employeeDetails.GetEmployeeDetail(employeeId);
        }
    }
}
