﻿using EmployeeApp.PresentationLayer.UI.Web.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeApp.PresentationLayer.PresentationLogic;

namespace EmployeeApp.PresentationLayer.UI.Web.Presenter
{
    public class EmployeePresenter : IEmployeePresenter
	{
        IEmployeeView view;
        IEmployeePresentationLogic presentationLogic;

        public EmployeePresenter(IEmployeeView view, IEmployeePresentationLogic presentationLogic)
        {
			this.view = view;
            this.presentationLogic = presentationLogic;
        }

        public void GetEmployeeDetails(int employeeId)
        {
            // TODO: Figure out if data separation is needed.
            var employee = presentationLogic.GetEmployeeDetail(employeeId);

            view.FirstName = employee.FirstName;
            view.LastName = employee.LastName;
            view.Address = employee.Address;
        }

        public bool SaveEmployeeDetail()
        {
			throw new NotImplementedException();
		}
    }
}
