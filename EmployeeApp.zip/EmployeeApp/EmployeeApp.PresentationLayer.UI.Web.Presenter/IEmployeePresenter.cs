﻿namespace EmployeeApp.PresentationLayer.UI.Web.Presenter
{
	public interface IEmployeePresenter
	{
		void GetEmployeeDetails(int employeeId);
		bool SaveEmployeeDetail();
	}
}