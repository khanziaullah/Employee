﻿using EmployeeApp.BusinessLayer;
using EmployeeApp.ServiceLayer.MessageTypes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace EmployeeApp.ServiceLayer.ServiceInterfaces
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IEmployeeService" in both code and config file together.
    public class EmployeeServiceLogic : IEmployeeService
    {
        IEmployeeDetails employeeDetails;
        public EmployeeServiceLogic(IEmployeeDetails employeeDetails)
        {
            this.employeeDetails = employeeDetails;
        }
        public GetEmployeeDetailsResponse GetEmployeeDetails(GetEmployeeDetailsRequest request)
        {
            // TODO: This class should only be dealing with Business Entities and not DataLayer.Models
            var employee = employeeDetails.GetEmployeeDetail(request.EmployeeId);
            //return Mapper.Map<EmployeeDTO, GetEmployeeDetailsResponse>(employee);

            return new GetEmployeeDetailsResponse
            {
                FirstName = employee.FirstName,
                LastName = employee.LastName,
                Address = employee.Address,
            };
        }
    }
}
