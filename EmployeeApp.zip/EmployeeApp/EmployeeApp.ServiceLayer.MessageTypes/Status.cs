﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace EmployeeApp.ServiceLayer.MessageTypes
{
    [DataContract]
    public enum Status
    {
        [EnumMember]
        Success,
        [EnumMember]
        Error,
    }
}
