﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeApp.ServiceLayer.MessageTypes
{
    [DataContract]
    public class GetEmployeeDetailsRequest : RequestBase
    {
        [DataMember]
        public int EmployeeId { get; set; }
    }
}
