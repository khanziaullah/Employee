﻿using EmployeeApp.CrossCutting;
using EmployeeApp.ServiceLayer.ServiceInterfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using Unity;
using Unity.Interception.ContainerIntegration;
using Unity.Interception.Interceptors.InstanceInterceptors.InterfaceInterception;

namespace EmployeeApp.ServiceLayer.Services
{
    public class Global : System.Web.HttpApplication
    {

        public static UnityContainer container = new UnityContainer();
        protected void Application_Start(object sender, EventArgs e)
        {
            container.AddNewExtension<Interception>();

            container.RegisterType<IEmployeeService, EmployeeServiceLogic>(
                new Interceptor<InterfaceInterceptor>(),
                new InterceptionBehavior<RequestResponseInterceptionBehavior>(),
                new InterceptionBehavior<LoggingInterceptionBehavior>());

            container.RegisterType<BusinessLayer.IEmployeeDetails, BusinessLayer.EmployeeDetails>(
                new Interceptor<InterfaceInterceptor>(),
                new InterceptionBehavior<LoggingInterceptionBehavior>());

            container.RegisterType<DataLayer.IEmployeeDetails, DataLayer.EmployeeDetails>(
                new Interceptor<InterfaceInterceptor>(),
                new InterceptionBehavior<LoggingInterceptionBehavior>());
        }
    }
}